var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator');
var app = express();
var http = require('http');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL
|| 'mongodb://jbrill01:pass123@ds053300.mongolab.com:53300/heroku_app31674934';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

var returning = {
	'characters': [],
	'students': []
};

app.post('/sendLocation', function(request, response) {
	if (!(request.body.login&&request.body.lat&&request.body.lng)) {
		response.send(500);
	}
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;
	var time = new Date();
	time = time.toString();
	var toInsert = {
		"login": login,
		"lat": lat,
		"lng": lng,
		"created_at": time
	};
	db.collection('locations', function(er, collection) {
		var id = collection.insert(toInsert, function(err, saved) {
			if (err) {
				response.send(500);
			}
			else {
				var dtbase = collection.find({});
				dtbase.sort({created_at:-1}).limit(100);
				dtbase.toArray(function(err, cursor) {
					for (var i = 0; i < cursor.length; i++) {
						returning.students[i] = cursor[i];
					}
				response.send(JSON.stringify(returning));
				});
			}
		});
	});
});

app.get('/locations.json', function(request, response) {
	db.collection('locations', function(er,collection) {
		var name = request.query.login;
		var rtn = [];
		if (!request.query.login) {
			response.send(rtn);
		} else {
			var dtbase = collection.find({'login' : name});
			dtbase.sort({created_at:-1}).limit(100);
			dtbase.toArray(function(err,cursor) {
				for (var i = 0; i < cursor.length; i++) {
					rtn[i] = cursor[i];
				}
				response.send(JSON.stringify(rtn));
			});
		}
	});
});

app.get('/', function(request, response) {
	var homePage = "<!DOCTYPE HTML><html><title>Where In the World!?</title></head>";
	db.collection('locations', function(er, collection) {
		if (true) {
			homePage+="<body><h1>Check-Ins</h1>";
			var dtbase = collection.find({});
			dtbase.sort({created_at:-1}).limit(100);
			dtbase.toArray(function(err, cursor) {
				for (var i = 0; i < cursor.length; i++) {
					homePage += "<p>Checked in at: " + cursor[i].created_at + ", Name: " + cursor[i].login + ", Lat: " + cursor[i].lat + ", Long: " + cursor[i].lng + "</p>";
				}
				homePage += "</body></html>"
				response.send(homePage);
			});
		} else {
				response.send(homePage+"<body><h1>Sorry, something seems to have gone wrong!</h1></body></html>");
			}
	});
});

app.get('/redline.json', function(request, response) {
	var resText='';
	var req = http.get("http://developer.mbta.com/lib/rthr/red.json", function(responder) {
		responder.on('data', function(chunk) {
			resText += chunk;
		});
		responder.on('end', function() {
			response.send(resText);
		});
	});
	req.on('error', function(error) {
		response.send(500);
	});
});

app.listen(process.env.PORT || 3000); // for local testing