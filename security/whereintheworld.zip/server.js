var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var validator = require('validator');
var http = require('http');

var mongoUri = process.env.MONGOLAB_URI ||
        process.env.MONGOHQ_URL ||
        'mongodb://localhost/whereintheworld';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
        db = databaseConnection;
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
});

app.get('/', function(request, response) {
        var toReturn = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Location Check-ins</title><link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet"></head><body><h2 class="sub-header">Check-ins</h2><div class="table-responsive"><table class="table table-striped"><thead><tr><th>Login</th><th>Location</th><th>Timestamp</th></tr></thead><tbody>';

        db.collection('students', function(er, collection) {
                collection.find({}).toArray(function(err, checkins) {
                        var sorted = sortCheckins(checkins);
                        var students = convertDates(sorted);
                        for (var i = 0; i < students.length; i++) {
                                toReturn += "<tr><td>" + students[i]['login'] +
                                        "</td><td>Latitude: " + students[i]['lat'] +
                                        ", Longitude: " + students[i]['lng'] +
                                        "</td><td>" + students[i]['created_at'] +
                                        "</td></tr>";
                        }
                        toReturn += '</tbody></table></div></body></html>';
                        response.send(toReturn);
                });
        });
});

function sortCheckins(checkins) {
        return checkins.sort(function(x,y) {
                return y['created_at'] - x['created_at'];
        });
}

function convertDates(checkins) {
        return checkins.map(function(checkin) {
                var temp = checkin;
                temp['created_at'] = new Date(checkin['created_at']).toString();
                return temp;
        });
}

function firstx(someArray, x) {
        var toReturn = [];
        for (var i = 0; i < x && i < someArray.length; i++) {
                toReturn.push(someArray[i]);
        }
        return toReturn;
}

app.post('/sendLocation', function(request, response) {
        var login = request.body.login;
        var lat = request.body.lat;
        var lng = request.body.lng;
        if (login && lat && lng) {
                var toInsert = {"login":login, "lat":lat, "lng":lng, "created_at":new Date().getTime()};
                db.collection('students', function(er, collection) {
                        collection.insert(toInsert, function(err) {
                                if (err) {
                                        response.send('<!DOCTYPE html><html><head><title>Where in the world?</title></head><body><h1>An error occured in modifying the database</h1></body></html>');
                                }
                                collection.find({}).toArray(function(errr, checkins) {
                                        var sorted = sortCheckins(checkins);
                                        var students = convertDates(sorted);
                                        students = firstx(students, 100);
                                        var toRespond = {};
                                        toRespond['characters'] = [];
                                        toRespond['students'] = students;
                                        response.send(toRespond);
                                });
                        });
                });
        }
});

app.get('/locations.json', function(request, response) {
        var login = request.query.login;
        db.collection('students', function(er, collection) {
                collection.find({'login':login}).toArray(function(err, checkins) {
                        var sorted = sortCheckins(checkins);
                        var students = convertDates(sorted);
                        students = firstx(students, 100);
                        response.send(students);
                });
        });
});

app.get('/redline.json', function(request, response) {
        var options = {
                host: 'developer.mbta.com',
                port: 80,
                path: '/lib/rthr/red.json',
                method: 'GET',
                headers: {
                        'Content-Type': 'application/json'
                }
        }
        var mbtaReq = http.request(options, function(mbtaResponse) {
                var toReturn = '';
                mbtaResponse.on('data', function(chunk) {
                        toReturn += chunk;
                });
                mbtaResponse.on('end', function() {
                        response.send(JSON.parse(toReturn));
                });
        });
        mbtaReq.end();
});

app.listen(process.env.PORT || 3000);
